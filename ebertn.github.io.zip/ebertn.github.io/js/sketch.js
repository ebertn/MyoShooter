var rocket;
var speed = 10;
var obs = [];

function setup() {
	var cnv = createCanvas(windowWidth, windowHeight);
	cnv.style('display', 'block');
	background(50);

	rocket = new Rocket(width, height);
}

function draw() {
	// put drawing code here
	if (frameCount % 100 == 0)
	{
		obs.push(new Obs);
	}

	background(50);

	rocket.update(); 
	rocket.show();

	for (var i = 0; i < obs.length; i++)
	{
		obs[i].update();
		obs[i].show();
	}

	orientation = {}
	$.get(
		"http://127.0.0.1:5000/output",
		function(data) {
			console.log('page content: ' + data);
			orientation = JSON.parse(data)
			rocket.pos.y = height*parseFloat(orientation.x)*2
			rocket.pos.x = width*parseFloat(orientation.y)*2
			console.log("orientation.x = " + orientation.x)
			console.log("parseFloat(orientation.x) = " + parseFloat(orientation.x))

			if (rocket.pos == )
			if (parseInt(orientation.status) == 1)
			{
				rocket.shoot();
			}
			
		}
	);

}

function windowResized() {
	resizeCanvas(windowWidth, windowHeight);
}

function keyPressed() {
	if (keyCode === LEFT_ARROW) {
		rocket.vel = createVector(-speed, 0);
	}
	if (keyCode === RIGHT_ARROW) {
		rocket.vel = createVector(speed, 0);
	}
	if (keyCode === UP_ARROW) {
		rocket.vel = createVector(0, -speed);
	}
	if (keyCode === DOWN_ARROW) {
		rocket.vel = createVector(0, speed);
	} 
	
	if (keyCode === DELETE) {
		console.log("Pressed space")
		rocket.shoot();
	}
}

function keyReleased() {
	if(keyCode !== DELETE){
		rocket.vel = createVector(0, 0);
	}
	
	return false; // prevent any default behavior
  }

